# archipelago 0.0.1.9000

* 20250226 - CRAN submission
* 20250302 - Added better space feature for x axis ticks to match the chromosome length of the dataset. Added several more specific parameters like two critical thresholds. 
* 20250509 - Initial development version.

